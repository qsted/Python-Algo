# -*- coding: utf-8 -*-
"""
Created on Tue Oct 26 16:15:30 2021

@author: Shuo.Qi.ext
"""

import pandas as pd



url1 = "http://amdwh-prod.slcloud.ch:5000/DataDesk/Rep02361?&FundClass='SLFDEFI FP'&"+"ReportDate='2019-11-30'&Language='FR'&Domicile=''&AuMNNADashboardUnit=''&ShowTerminatedFunds=''&ReportingCurrency='EUR'&$select=ReportDate,ISIN,FundClass,FundDefinition,FundDefinitionName,SecurityLongName,FundClassCcy,LegalForm,AssetClass,AssetClassName,AMBFundCategory,AMBClassificationInternal,AMBFundType,MgmFees,BenchmarkOfficial_AMF,BenchmarkTicker,NavDate,NAVPrice,ClassNetAsset,ClassNetAssetRC,FundNetAssetValue,FundNetAssetValueRC"

url2 = "http://amdwh-prod.slcloud.ch:5000/DataDesk/Rep02244?&FromDate='2021-10-25'&ReportDate='2021-10-25'&ISINs='FR0010556886,FR0013332509'&Periods='13W,1M,1W,2Y,5Y,YTD'&PortfolioGroupTypes=''&ShowOnlyME=''&$select=ISIN,Fund_Code,Fund_Definition,Performance_Period,BM_TWR_RC,Fund_TWR_Gross "

def GetTable(url):
    import requests
    import pandas as pd
    headers = {
      'Authorization': 'Basic c3dpc3Ncc2xyYmFtYTpDb2duaTIxJDA2'
    }  
    payload={}
    response = requests.request("GET", url, headers=headers, data=payload)
    df = pd.json_normalize(response.json()['value'])
    
    return df
   
df2=GetTable(url2)

#dff=pd.DataFrame(columns=('ISIN','Fund_or_Bench','13W','1M','1W','5Y','YTD','2Y'))
def TransformTableNum(df):
    import pandas as pd
    import numpy as np 
    dff=pd.DataFrame()
    col=['ISIN','Fund_or_Bench','13W','1M','1W','5Y','YTD','2Y']
    for i in df['ISIN'].unique():
        temp = df[df['ISIN']==i][['Performance_Period','BM_TWR_RC','Fund_TWR_Gross']]
        temp=temp.T
        temp.columns = temp.iloc[0]
        temp=temp.drop(temp.index[0])
        temp['ISIN']=i
        temp['Fund_or_Bench']=temp.index
        if '2Y' not in temp.columns:
            temp['2Y']=np.nan
        temp=temp[col]
        #temp=temp.sort_index(axis=1)
        temp=temp.sort_index(axis=0,ascending=False)
        dff=pd.concat([dff,temp])
    return dff


def TransformTableName(df):
    for i in df['ISIN'].unique():
        import pandas as pd
        import numpy as np 
        dff2=pd.DataFrame()
        df_temp = df[df['ISIN']==i][['ISIN','SecurityLongName','BenchmarkOfficial_AMF']]
        #df_temp.loc[1,:]=df_temp.loc[0].values.tolist()
        df_temp.loc[1,:]=[df_temp.iloc[0,0],df_temp.iloc[0,2],df_temp.iloc[0,1]]
        df_temp['Fund_or_Bench']=['Fund_TWR_Gross','BM_TWR_RC']
        del df_temp['BenchmarkOfficial_AMF']
        df_temp.rename(columns = {'SecurityLongName':'MULTI ASSET'}, inplace = True)
        dff2=pd.concat([dff2,df_temp])
        
    return dff2


df_num=GetTable(url2)
df_name = GetTable(url1)   

test2=TransformTableNum(df_num)
test1=TransformTableName(df_name)
df_final=pd.merge(test2,test1,how='left',on=['ISIN','Fund_or_Bench'])





