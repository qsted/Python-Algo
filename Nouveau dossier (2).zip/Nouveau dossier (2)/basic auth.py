# -*- coding: utf-8 -*-
"""
Created on Tue Oct 26 13:53:23 2021

@author: Shuo.Qi.ext
"""

import dash
import dash_auth
import dash_html_components as html
from dash.dependencies import Input, Output
from flask import request

# Keep this out of source code repository - save in a file or a database
VALID_USERNAME_PASSWORD_PAIRS = [
    ['hello', 'world'],
    ['shuo','mm']
]



app = dash.Dash(__name__, )
auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)

app.layout = html.Div([

    html.H2('show-output',),
    html.Button('press to show username', id='button')

], className='container')

@app.callback(
    Output(component_id='show-output'),
    #[Input(component_id='button', component_property='n_clicks')]
)
def update_output_div():
    username = request.authorization['username']
    print(username)

    return username
 

app.scripts.config.serve_locally = True


if __name__ == '__main__':
    app.run_server(debug=False)