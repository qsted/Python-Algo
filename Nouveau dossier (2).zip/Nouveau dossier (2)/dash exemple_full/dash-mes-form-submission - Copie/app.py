import datetime as dt
import re
from textwrap import dedent

import dash
import dash_core_components as dcc
import dash_html_components as html

import dash_table
import pandas as pd

import sqlalchemy as db
from dash.dependencies import Input, Output, State

# SQL Engine
disk_engine = db.create_engine(
    "sqlite:///data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()
metadata = db.MetaData()
SQL_table = db.Table(
    "data_entries",
    metadata,
    db.Column("operator_id", db.String(255)),
    db.Column("reagent", db.String(255)),
    db.Column("time_elapsed", db.String(255)),
    db.Column("amount_pipetted", db.Float()),
    db.Column("time_stamp", db.DATETIME, primary_key=True),
)
df = pd.read_sql_query(
            dedent(
                """
        SELECT * from data_entries
        """
            ),
            disk_engine,
        )

app = dash.Dash(__name__)
server = app.server

app.config.suppress_callback_exceptions = False

app.layout = html.Div(
    [
        html.Div(
            [
                html.Img(src="assets/dash-logo.png", className="app__logo"),
                html.H4("MES FORM SUBMISSION", className="header__text"),
            ],
            className="app__header",
        ),
        html.Div(
            [
                dcc.Tabs(
                    id="tabs",
                    value="data-entry",
                    children=[
                        dcc.Tab(
                            label="DATA ENTRY",
                            value="data-entry",
                            children=[
                                html.Div(
                                    [
                                        html.Div(
                                            [
                                                html.P(
                                                    "Operator ID:",
                                                    className="input__heading",
                                                ),
                                                dcc.Input(
                                                    id="enter-operator-id",
                                                    value="User",
                                                    placeholder="Enter operator ID.",
                                                    className="oper__input",
                                                ),
                                            ],
                                            className="input__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "Reagent:",
                                                    className="input__heading",
                                                ),
                                                dcc.Dropdown(
                                                    id="select-reagent",
                                                    options=[
                                                        {"label": i, "value": i}
                                                        for i in [
                                                            "Acetone",
                                                            "Isopropanol",
                                                            "Toluene",
                                                        ]
                                                    ],
                                                    value="Acetone",
                                                    placeholder="Select reagent.",
                                                    className="reag__select",
                                                ),
                                            ],
                                            className="dropdown__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "Time (HH:MM:SS)",
                                                    className="input__heading",
                                                ),
                                                dcc.Input(
                                                    id="enter-time",
                                                    value="00:00:00",
                                                    placeholder="Enter Time (HH:MM:SS)",
                                                    className="time__input",
                                                ),
                                            ],
                                            className="input__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "Amount Pipetted (mL):",
                                                    className="input__heading",
                                                ),
                                                dcc.Input(
                                                    id="enter-pipetted",
                                                    type="number",
                                                    value="0",
                                                    placeholder="Enter amount in (mL).",
                                                    className="vol__input",
                                                ),
                                            ],
                                            className="input__container",
                                        ),
                                        html.Div(
                                            [
                                                html.Button(
                                                    "SUBMIT ENTRY",
                                                    id="submit-entry",
                                                    className="submit__button",
                                                ),
                                                html.Button(
                                                    "CLEAR DATA",
                                                    id="clear-button",
                                                    style={"margin-right": "2.5%"},
                                                    className="clear__button",
                                                ),
                                            ]
                                        ),
                                    ],
                                    className="container__1",
                                )
                            ],
                        ),
                        dcc.Tab(
                            label="VIEW DATA ENTRY",
                            value="view-entry",
                            children=[
                                html.Div(
                                    [
                                        
                                        html.Br(),
                                        html.Div(
                                            children=[
                
                                                html.Button(
                                                    "CLEAR DATA2",
                                                    id="clear-button2",
                                                    style={"margin-right": "2.5%"},
                                                    className="clear__button",
                                                ),
                                            ]
                                        ),
                                    ],
                                    className="graph_container",
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            [
                                                dash_table.DataTable(
                                                    id='table',
                                                    columns=[{"name": i, "id": i} for i in df.columns],
                                                    data=df.to_dict('records'),
                                                    )
                                            ],
                                            className="table__1",
                                        )
                                    ],
                                    className="table__container",
                                ),
                            ],
                        ),
                    ],
                )
            ],
            className="tabs__container",
        ),
    ],
    className="app__container",
)


@app.callback(
    Output("tabs", "value"),
    [Input("submit-entry", "n_clicks")],
    [Input("clear-button", "n_clicks")],
    [
        State("enter-operator-id", "value"),
        State("select-reagent", "value"),
        State("enter-time", "value"),
        State("enter-pipetted", "value"),
    ],
)
def entry_to_db(submit_entry, clear,operator_id, reagent, time_elapsed, amount_pipetd):
    if submit_entry:
        sample_entry = [
            {
                "operator_id": operator_id,
                "reagent": reagent,
                "time_elapsed": time_elapsed,
                "amount_pipetted": amount_pipetd,
                "time_stamp": dt.datetime.now(),
            }
        ]
        insert_entry = connection.execute(db.insert(SQL_table), sample_entry)
    if clear:
        query = db.delete(SQL_table)
        results = connection.execute(query)
    return "view-entry"
    raise dash.exceptions.PreventUpdate




if __name__ == "__main__":
    app.run_server(debug=False)
