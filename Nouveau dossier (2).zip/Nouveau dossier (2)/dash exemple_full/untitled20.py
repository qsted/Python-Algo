# -*- coding: utf-8 -*-
"""
Created on Wed Oct 27 15:30:38 2021

@author: Shuo.Qi.ext
"""
import sqlalchemy as db
from dash.dependencies import Input, Output, State
from sqlalchemy import select, update, delete
import pandas as pd
from textwrap import dedent
import os 
os.chdir(r'C:\Users\Shuo.Qi.ext\OneDrive - Swiss Life Asset Managers\Bureau\dash-mes-form-submission')
disk_engine = db.create_engine(
    "sqlite:///data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()
metadata = db.MetaData()
SQL_table = db.Table(
    "data_entries",
    metadata,    
    db.Column("Username", db.String(255)),
    db.Column("SecurityLongName", db.String(255)),    
    db.Column("isin", db.String(255)),
    db.Column("stand_bench", db.String(255)),
    db.Column("custom_bench", db.String(255)),
)

username='shuo'

data= pd.read_sql_query(dedent("SELECT * from data_entries re Username="whe+username),disk_engine, )