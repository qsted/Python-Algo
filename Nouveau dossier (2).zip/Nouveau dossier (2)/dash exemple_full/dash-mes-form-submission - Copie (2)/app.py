import datetime as dt
import re
from textwrap import dedent

import dash
import dash_core_components as dcc
import dash_html_components as html

import dash_table
import pandas as pd

import sqlalchemy as db
from dash.dependencies import Input, Output, State

data1=pd.read_excel('data1.xlsx')
# SQL Engine
disk_engine = db.create_engine(
    "sqlite:///data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()
metadata = db.MetaData()
SQL_table = db.Table(
    "data_entries",
    metadata,
    db.Column("team", db.String(255)),
    db.Column("fund_id", db.String(255)),
    db.Column("bench_id", db.String(255)),
    db.Column("start_date", db.String(255)),
    db.Column("end_date", db.String(255)),
)

metadata.create_all(disk_engine)
df = pd.read_sql_query(
            dedent(
                """
        SELECT * from data_entries
        """
            ),
            disk_engine,
        )
app = dash.Dash(__name__)
server = app.server

app.config.suppress_callback_exceptions = False

app.layout = html.Div(
    [
        html.Div(
            [
                html.Img(src="assets/dash-logo.png", className="app__logo"),
                html.H4("MES FORM SUBMISSION", className="header__text"),
            ],
            className="app__header",
        ),
        html.Div(
            [
                dcc.Tabs(
                    id="tabs",
                    value="data-entry",
                    children=[
                        dcc.Tab(
                            label="DATA ENTRY",
                            value="data-entry",
                            children=[
                                html.Div(
                                    [
                                       html.Div(
                                            [
                                                html.P(
                                                    "Team Name:",
                                                    className="input__heading",
                                                ),
                                                dcc.Dropdown(
                                                    id="team",
                                                    options=[
                                                        {"label": i, "value": i}
                                                        for i in ["PAM","TPAM"]
                                                        
                                                    ],
                                                    value="",
                                                    placeholder="Select team.",
                                                    className="reag__select",
                                                ),
                                            ],
                                            className="dropdown__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "Fund Name:",
                                                    className="input__heading",
                                                ),
                                                dcc.Dropdown(
                                                    id="select-fund",
                                                    options=[
                                                        {"label": i, "value": i}
                                                        #for i in ["Acetone","Isopropanol","Toluene",]
                                                        for i in data1['fund_name']
                                                    ],
                                                    value="",
                                                    placeholder="Select fund.",
                                                    className="reag__select",
                                                ),
                                            ],
                                            className="dropdown__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "Bench Name:",
                                                    className="input__heading",
                                                ),
                                                dcc.Dropdown(
                                                    id="select-bench",
                                                    options=[
                                                        {"label": i, "value": i}
                                                        #for i in ["Acetone","Isopropanol","Toluene",]
                                                        for i in data1['bench_name']
                                                    ],
                                                    value="",
                                                    placeholder="Select bench",
                                                    className="reag__select",
                                                ),
                                            ],
                                            className="dropdown__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "Start Date:DDMMYYYY",
                                                    className="input__heading",
                                                ),
                                                dcc.Input(
                                                    id="start-date",
                                                    value="",
                                                    placeholder="Enter Start Date",
                                                    className="oper__input",
                                                ),
                                            ],
                                            className="input__container",
                                        ),
                                        html.Div(
                                            [
                                                html.P(
                                                    "End Date:DDMMYYYY",
                                                    className="input__heading",
                                                ),
                                                dcc.Input(
                                                    id="end-date",
                                                    value="",
                                                    placeholder="Enter Start Date",
                                                    className="oper__input",
                                                ),
                                            ],
                                            className="input__container",
                                        ),
                                        html.Div(
                                            [
                                                html.Button(
                                                    "SUBMIT ENTRY",
                                                    id="submit-entry",
                                                    className="submit__button",
                                                ),
                                                html.Button(
                                                    "CLEAR DATA",
                                                    id="clear-button",
                                                    style={"margin-right": "2.5%"},
                                                    className="clear__button",
                                                ),
                                            ]
                                        ),
                                    ],
                                    className="container__1",
                                )
                            ],
                        ),
                        dcc.Tab(
                            label="VIEW DATA ENTRY",
                            value="view-entry",
                            children=[
                                html.Div(
                                    [
                                        
                                        html.Br(),
                                        html.Div(
                                            children=[
                
                                                html.Button(
                                                    "CLEAR DATA2",
                                                    id="clear-button2",
                                                    style={"margin-right": "2.5%"},
                                                    className="clear__button",
                                                ),
                                            ]
                                        ),
                                    ],
                                    className="graph_container",
                                ),
                                html.Div(
                                    [
                                        html.Div(
                                            [
                                                dash_table.DataTable(
                                                    id='table',
                                                    columns=[{"name": i, "id": i} for i in df.columns],
                                                    data=df.to_dict('records'),
                                                    )
                                            ],
                                            className="table__1",
                                        )
                                    ],
                                    className="table__container",
                                ),
                            ],
                        ),
                    ],
                )
            ],
            className="tabs__container",
        ),
    ],
    className="app__container",
)


@app.callback(
    Output("tabs", "value"),
    [Input("submit-entry", "n_clicks")],
    [Input("clear-button", "n_clicks")],
    [
        State("team", "value"),
        State("select-fund", "value"),
        State("select-bench", "value"),
        State("start-date", "value"),
        State("end-date", "value")
    ],
)
def entry_to_db(submit_entry, clear, team, fund_id, bench_id, start_date, end_date):
    if submit_entry:
        sample_entry = [
            {
                "team":team,
                "fund_id": fund_id,
                "bench_id": bench_id,
                "start_date": start_date,
                "end_date": end_date,
                
            }
        ]
        insert_entry = connection.execute(db.insert(SQL_table), sample_entry)
    if clear:
        query = db.delete(SQL_table)
        results = connection.execute(query)
    return "view-entry"
    raise dash.exceptions.PreventUpdate




if __name__ == "__main__":
    app.run_server(debug=False)
