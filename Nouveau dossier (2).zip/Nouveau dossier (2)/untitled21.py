# -*- coding: utf-8 -*-
"""
Created on Wed Nov  3 10:55:09 2021

@author: Shuo.Qi.ext
"""
import sqlalchemy as db
import pandas as pd
from textwrap import dedent
import os 
import requests
import numpy as np
os.chdir(r"C:\Users\Shuo.Qi.ext\OneDrive - Swiss Life Asset Managers\Bureau\slamprojet\python-project\demo_steph\PerformanceReport\datasets")

disk_engine = db.create_engine(
    "sqlite:///data_entry.db", connect_args={"check_same_thread": False}
)
connection = disk_engine.connect()
var_username='hello'
date='2021-11-01'
def getAmdatadeskData(date):
    
    df = pd.read_sql_query(dedent("SELECT * from data_entries where UserName = '{}' ".format(var_username)),disk_engine, )

    lstFundClass = ','.join(df["FundClass"])
    lstIsin = ','.join(df["isin"])
          
    
    urlRep02361_FundInfo = "http://amdwh-prod.slcloud.ch:5000/DataDesk/Rep02361?" \
        +"&FundClass='"+lstFundClass+"'&ReportDate='"+date+"'&Language='FR'&Domicile=''&AuMNNADashboardUnit=''&ShowTerminatedFunds=''&ReportingCurrency='EUR'" \
        +"&$select=ReportDate,ISIN,FundClass,FundDefinition,FundDefinitionName,SecurityLongName,FundClassCcy,LegalForm,AssetClass,AssetClassName,AMBFundCategory,AMBClassificationInternal,AMBFundType,MgmFees,BenchmarkOfficial_AMF,BenchmarkTicker,NavDate,NAVPrice,ClassNetAsset,ClassNetAssetRC,FundNetAssetValue,FundNetAssetValueRC"
    
    urlRep02244_perf = "http://amdwh-prod.slcloud.ch:5000/DataDesk/Rep02244?" \
        +"&FromDate='"+date+"'&ReportDate='"+date+"'&ISINs='"+ lstIsin \
        +"'&Periods='13W,1M,1W,2Y,5Y,YTD'&PortfolioGroupTypes=''&ShowOnlyME=''&$select=ISIN,Fund_Code,Fund_Definition,Performance_Period,BM_TWR_RC,Fund_TWR_Gross "

        
    
    df_num=GetTable( urlRep02244_perf)    
    df_name = GetTable(urlRep02361_FundInfo)   
    
    
    if (df_num.empty == False and df_name.empty ==False) :
        test2=TransformTableNum(df_num)
        #test1=TransformTableName(df_name)
        df_final=pd.merge(test2,df_name,how='left',on=['ISIN'])
    
        #return make_dash_table(df_final)  
        return df_final
    return ''

def GetTable(url):
    headers = {
      'Authorization': 'Basic c3dpc3Ncc2xyYmFtYTpDb2duaTIxJDA2'
    }  
    payload={}
    response = requests.request("GET", url, headers=headers, data=payload)

    df = pd.json_normalize(response.json()['value'])

    return df
   

def TransformTableNum(df):
    col=['ISIN',
        'fund_13W',
        'fund_1M',
        'fund_1W',
        'fund_5Y',
        'fund_YTD',
        'fund_2Y',
        'bench_13W',
        'bench_1M',
        'bench_1W',
        'bench_5Y',
        'bench_YTD',
        'bench_2Y']
           
    dff=pd.DataFrame(columns=col)


    for i in df['ISIN'].unique():
        temp = df[df['ISIN']==i][['Performance_Period','BM_TWR_RC','Fund_TWR_Gross']]
        temp=temp.T
        temp.columns = temp.iloc[0]
        temp=temp.drop(temp.index[0])
        temp['ISIN']=i
        
        list_dif=[i  for i in ['13W','YTD','1W','1M','5Y','2Y'] if i not in temp.columns.tolist()]
        for x in list_dif:
            temp[x]=np.nan
    
        row=[i,
            temp['13W']['Fund_TWR_Gross'],
            temp['1M']['Fund_TWR_Gross'],
            temp['1W']['Fund_TWR_Gross'],
            temp['5Y']['Fund_TWR_Gross'],
            temp['YTD']['Fund_TWR_Gross'],
            temp['2Y']['Fund_TWR_Gross'],
            temp['13W']['Fund_TWR_Gross']-temp['13W']['BM_TWR_RC'],
            temp['1M']['Fund_TWR_Gross']-temp['1M']['BM_TWR_RC'],
            temp['1W']['Fund_TWR_Gross']-temp['1W']['BM_TWR_RC'],
            temp['5Y']['Fund_TWR_Gross']-temp['5Y']['BM_TWR_RC'],
            temp['YTD']['Fund_TWR_Gross']-temp['YTD']['BM_TWR_RC'],
            temp['2Y']['Fund_TWR_Gross']-temp['2Y']['BM_TWR_RC']
            ]    
        dff.loc[len(dff)]=row 
        
        return dff


a=getAmdatadeskData(date)
    


a=[1,[1,2]]
for i in a:
    print(i)